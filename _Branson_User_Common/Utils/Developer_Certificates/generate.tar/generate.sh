#Use this script for development purpose only ! Not for production use !!!




#HMI communication specific keys/certificate generation
openssl genrsa -aes256 -passout pass:CAPass1$ > developer-ca-key.pem
openssl req -new -x509 -days 10950 -sha384  -key developer-ca-key.pem -out developer-ca-cert.pem -subj "/C=IN/ST=MH/L=Pune/O=Emerson/OU=Branson/CN=BransonCA" -passin pass:CAPass1$

openssl x509 -in developer-ca-cert.pem -text

openssl genrsa -aes256 -passout pass:ServerPass1$ > developer-server-key.pem
openssl req -new -key developer-server-key.pem -out developer-server-req.pem -subj "/C=IN/ST=MH/L=Pune/O=Emerson/OU=Branson/CN=BransonSC" -passin pass:ServerPass1$

openssl x509 -req -days 10950 -sha384 -set_serial 01 -in developer-server-req.pem -out developer-server-cert.pem -CA developer-ca-cert.pem -CAkey developer-ca-key.pem -passin pass:CAPass1$

openssl x509 -in developer-server-cert.pem -text

openssl genrsa -aes256 -passout pass:ClientPass1$ > developer-client-key.pem
openssl req -new -key developer-client-key.pem -out developer-client-req.pem -subj "/C=IN/ST=MH/L=Pune/O=Emerson/OU=Branson/CN=BransonHMI" -passin pass:ClientPass1$

openssl x509 -req -days 10950 -sha384 -set_serial 02 -in developer-client-req.pem -out developer-client-cert.pem -CA developer-ca-cert.pem -CAkey developer-ca-key.pem -passin pass:CAPass1$

openssl x509 -in developer-client-cert.pem -text

echo -n "ServerPass1$" | openssl enc -e -aes-256-cbc -nosalt -k BransonTopSecret@1234# -out developer-server-data.enc

echo -n "ClientPass1$" | openssl enc -e -aes-256-cbc -nosalt -k BransonTopSecret@1234# -out developer-client-data.enc


openssl genrsa -aes256 -passout pass:configClientPass1$ > developer-configClient-key.pem
openssl req -new -key developer-configClient-key.pem -out developer-configClient-req.pem -subj "/C=IN/ST=MH/L=Pune/O=Emerson/OU=Branson/CN=BransonConfig" -passin pass:configClientPass1$

openssl x509 -req -days 10950 -sha384 -set_serial 02 -in developer-configClient-req.pem -out developer-configClient-cert.pem -CA developer-ca-cert.pem -CAkey developer-ca-key.pem -passin pass:CAPass1$

openssl x509 -in developer-configClient-cert.pem -text

echo -n "configClientPass1$" | openssl enc -e -aes-256-cbc -nosalt -k BransonTopSecret@1234# -out developer-configClient-data.enc




#Secure Configuration specific keys generation

echo -n "ConfigPass1$" | openssl enc -e -aes-256-cbc -pbkdf2 -iter 10000 -k BransonTopSecret@1234# -out developer-conf-key.enc
